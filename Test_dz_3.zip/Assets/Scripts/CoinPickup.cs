using UnityEngine;
using TMPro;

public class CoinPickup : MonoBehaviour
{
    private int _coinCount;
    [SerializeField] private TextMeshProUGUI _winBanner;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Coin>()) 
        {
            _coinCount++;
            if (_coinCount >= 4) 
            {
                _winBanner.gameObject.SetActive(true);
            }
            Destroy(other.gameObject);
        }
    }
}
