using TMPro;
using TMPro.EditorUtilities;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class PlayerMovement : MonoBehaviour
{
    [Header("Walking")]
    [SerializeField] private float _speed;

    [Header("Sprinting")]
    [SerializeField] private KeyCode _sprintKey;
    [SerializeField] private float _speedMultiplayer;

    private Vector3 _moveDirection;

    private Rigidbody _rb;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(_sprintKey))
        {
            _speed *= _speedMultiplayer;
        }
        else if (Input.GetKeyUp(_sprintKey))
        {
            _speed /= _speedMultiplayer;
        }
    }

    private void FixedUpdate()
    {
        _moveDirection.x = Input.GetAxis("Horizontal");
        _moveDirection.z = Input.GetAxis("Vertical");

        transform.Translate(_moveDirection * _speed);
    }
}