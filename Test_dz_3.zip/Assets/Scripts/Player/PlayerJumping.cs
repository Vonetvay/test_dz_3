using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(GroundChecker))]
public class PlayerJumping : MonoBehaviour
{
    [Header("Jumping")]
    [SerializeField] private KeyCode _jumpKey;
    [SerializeField] private float _jumpForce;

    [Header("Jumping Buffer")]
    [SerializeField] private float _keyPresetSaveTime;
    private bool _jumpKeyPreset;
    
    private Rigidbody _rb;
    private GroundChecker _groundChecker;

    private void Awake()
    {
       _rb = GetComponent<Rigidbody>();
        _groundChecker = GetComponent<GroundChecker>();
    }

    private void Update()
    {
        if (Input.GetKeyDown(_jumpKey))
        {
            SaveToJumpBuffer();
        }
        if (_jumpKeyPreset && _groundChecker.GetOnGround())
        {
            _jumpKeyPreset = false;
            _rb.velocity = new Vector3(_rb.velocity.x, 0, _rb.velocity.z);
            Jump(_jumpForce);
        }
    }

    private void SaveToJumpBuffer() 
    {
        _jumpKeyPreset = true;
        StopAllCoroutines();
        StartCoroutine(ResetCanJump());
    }

    private IEnumerator ResetCanJump()
    {
        yield return new WaitForSeconds(_keyPresetSaveTime);
        _jumpKeyPreset = false;
    }

    private void Jump(float _force) 
    {
        _rb.AddForce(_force * Vector3.up, ForceMode.VelocityChange);
    }
}
