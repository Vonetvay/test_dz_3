using UnityEngine;

public class GroundChecker : MonoBehaviour
{
    [SerializeField] private Vector3 _rayOffset;
    [SerializeField] private float _rayLength;
    [SerializeField] private LayerMask _verificationLayer;

    private bool _onGround;

    private void Update()
    {
        CheckGround();
    }

    private void CheckGround() 
    {
        Ray _ray = new Ray(transform.position + _rayOffset, Vector3.down);
        _onGround = Physics.Raycast(_ray, _rayLength, _verificationLayer);
    }

    public bool GetOnGround() => _onGround;
}
