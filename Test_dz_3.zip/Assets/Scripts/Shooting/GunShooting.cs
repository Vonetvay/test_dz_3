using UnityEngine;

[RequireComponent(typeof(BulletSpawner))]
public class GunShooting : MonoBehaviour
{
    [SerializeField] float _shootIntervalTime;

    private BulletSpawner _bulletSpawner;

    private void Awake()
    {
        _bulletSpawner = GetComponent<BulletSpawner>();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(1)) 
        {
            InvokeRepeating("Shoot", 0f, .2f);
        }
        else if (Input.GetMouseButtonUp(1)) 
        {
            CancelInvoke();
        }
    }

    private void Shoot() 
    {
        _bulletSpawner.Spawn();
    }
}
