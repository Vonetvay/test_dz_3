using UnityEngine;

public class Bullet : MonoBehaviour
{
    [SerializeField] private float _lifeTime;
    [SerializeField] private float _speed;

    private void Awake()
    {
        Invoke("Death", _lifeTime);
    }

    private void FixedUpdate()
    {
        transform.Translate(Vector3.forward * _speed);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<BoxDestroyer>())
        {
            collision.gameObject.GetComponent<BoxDestroyer>().BeginDestroy();
        }
        Death();
        CancelInvoke();
    }

    private void Death() 
    {
        Destroy(gameObject);
    }
}
