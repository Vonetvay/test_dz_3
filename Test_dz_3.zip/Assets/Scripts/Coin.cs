using UnityEngine;

public class Coin : MonoBehaviour
{
    [SerializeField] private float _rotateSpeed;

    private void FixedUpdate()
    {
        Vector3 _rotation = transform.eulerAngles;
        _rotation.y += _rotateSpeed;
        transform.eulerAngles = _rotation;
    }
}
